package nftappp;

public class Message {
	public String message;
	public String encryption;
	public String sender;
	public String recipient;
	public int timer;
	public int tenPoint;
	public boolean encrypt;
	public boolean point;
	public Minimessage c;
	public Message(String message, String encryption, String sender, String recipient, int timer, int tenPoint
			, boolean encrypt, boolean point, Minimessage c){
		this.message = message;
		this.encryption = encryption;
		this.sender = sender;
		this.recipient = recipient;
		this.timer = timer;
		this.tenPoint = tenPoint;
		this.encrypt = encrypt;
		this.point = point;
		this.c = c;
	}
	public void DeleteMessage(Message n){
		n = null;
	}
	public void ActivateTimer(){
		
	}
}
