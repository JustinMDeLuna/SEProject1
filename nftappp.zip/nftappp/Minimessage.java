package nftappp;

public class Minimessage {
	public char mm;
	public Minimessage(char mm){
		this.mm = mm;
	}
	// states s for sent, d for delivered, u for unencrypted, t for unlocked, o for opened, r for read.
	public char setMini(char mm){
		return mm;
	}
}
