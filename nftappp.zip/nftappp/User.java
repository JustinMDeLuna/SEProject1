package nftappp;

import java.util.Objects;

public class User {

	private Conversation[] convos;
	private String[] contacts;
	private String username, password;
	public User(String username, String password, String[] contacts, Conversation[] convos){
		this.username = "null";
		this.password = "null";
		this.contacts = new String[30];
		this.convos = new Conversation[30];
	}
	public String SendMessage(String message, String encryption, String recipient, int timer, int tenPoint
			, boolean encrypt, boolean point, Minimessage c){
		Message toSend = new Message(message,encryption,username,recipient,timer,tenPoint,encrypt,point,c);
		//system sends message
		return "Sent";
	}
	public String RecieveMessage(Message recieved){
		
		return recieved.message;
	}
	public String OpenMessage(String encryption, int tenPoint,Message recieved){
		boolean encrypt = true;
		boolean point = true;
		if(recieved.encrypt){
			if(!Objects.equals(encryption,recieved.encryption)){
				encrypt = false;
			}
		}
		if(recieved.point){
			if(tenPoint == recieved.tenPoint){
				point = false;
			}
		}
		if (point && encrypt){
			recieved.c.mm = 'u';
			recieved.ActivateTimer();
			return recieved.message;
		}
		else{
			return "failed attempt";
		}
	}
	public boolean AddContact(String username){
		//if username is on contact list add, else do not add
		if(contacts.length < 30){
			contacts[contacts.length+1]= username;
		}
		else{
			return false;
		}
		return true;
	}
	public void deleteConversation(int id){
		convos[id] = null;
	}
}
