package nftappp;

public class Conversation {

	public Conversation(){
		int id;
		Message[] messages = new Message[50];
		String user1, user2;
	}
}
